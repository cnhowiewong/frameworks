//
//  TestPerson.h
//  TestProject
//
//  Created by 王厚一 on 2021/6/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestPerson : NSObject

- (void)foo;

@end

NS_ASSUME_NONNULL_END
